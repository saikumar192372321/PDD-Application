import SwiftUI

// MARK: - Admin Orders View (Refined B2B Order Management)
struct AdminOrdersView: View {
    @ObservedObject var productStore: GroceryProductStore
    @EnvironmentObject var tabBarState: TabBarState
    
    var body: some View {
        ZStack {
            AppBackground()
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 24) {
                    // Premium Header
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Order Management")
                            .font(.system(size: 32, weight: .black))
                            .foregroundColor(AppColors.textPrimary)
                        Text("Track and fulfill business orders")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(AppColors.textSecondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 24)
                    .padding(.top, 16)

                    if productStore.orders.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "tray.and.arrow.down.fill")
                                .font(.system(size: 60))
                                .foregroundStyle(AppColors.primaryGradient.opacity(0.2))
                            Text("No pending orders")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(AppColors.textSecondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.top, 100)
                    } else {
                        LazyVStack(spacing: 16) {
                            ForEach(productStore.orders) { order in
                                OrderRow(order: order, productStore: productStore)
                            }
                        }
                        .padding(.horizontal, 24)
                    }
                }
                .padding(.bottom, 100)
            }
        }
        .navigationTitle("Order Management")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: { showCreateOrder = true }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 18))
                        .foregroundColor(AppColors.primary)
                }
            }
        }
        .sheet(isPresented: $showCreateOrder) {
            AdminCreateOrderView(productStore: productStore)
                .environmentObject(tabBarState)
        }
        .onAppear {
            Task { await productStore.fetchOrders() }
        }
        .refreshable {
            Task { await productStore.fetchOrders() }
        }
    }
    @State private var showCreateOrder = false
}

// MARK: - Order Row Card
struct OrderRow: View {
    let order: Order
    @ObservedObject var productStore: GroceryProductStore
    
    var body: some View {
        NavigationLink(destination: AdminOrderDetailView(productStore: productStore, order: order)) {
            VStack(spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Order #\(order.id.prefix(8).uppercased())")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(AppColors.textPrimary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        Text(order.date.formatted(date: .abbreviated, time: .omitted))
                            .font(.system(size: 12))
                            .foregroundColor(AppColors.textSecondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        Text(order.userEmail)
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(AppColors.primary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                    }
                    
                    Spacer()
                    
                    Text("₹\(Int(order.total))")
                        .font(.system(size: 18, weight: .black))
                        .foregroundColor(AppColors.primary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.6)
                }
                
                Divider()
                
                HStack {
                    OrderStatusBadge(status: order.status)
                    Spacer()
                    PaymentBadge(status: order.paymentStatus)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 11))
                        .foregroundColor(AppColors.textSecondary.opacity(0.4))
                        .padding(.leading, 8)
                }
            }
            .padding(16)
            .background(AppColors.surfaceLight)
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.02), radius: 8, x: 0, y: 3)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Order Status Badge
struct OrderStatusBadge: View {
    let status: OrderStatus
    
    var body: some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 6, height: 6)
            Text(status.rawValue)
                .font(.system(size: 11, weight: .semibold))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(color.opacity(0.1))
        .foregroundColor(color)
        .cornerRadius(8)
    }
    
    private var color: Color {
        switch status {
        case .pending: return .orange
        case .processing: return .blue
        case .outForDelivery: return .purple
        case .delivered: return AppColors.success
        case .cancelled: return .red
        }
    }
}

// MARK: - Payment Badge
struct PaymentBadge: View {
    let status: PaymentStatus
    
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: status == .paid ? "checkmark.circle.fill" : "exclamationmark.circle")
                .font(.system(size: 10))
            Text(status.rawValue)
                .font(.system(size: 11, weight: .semibold))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(color.opacity(0.1))
        .foregroundColor(color)
        .cornerRadius(8)
    }
    
    private var color: Color {
        switch status {
        case .paid: return AppColors.success
        case .pending: return .orange
        case .failed, .refunded: return .red
        }
    }
}
